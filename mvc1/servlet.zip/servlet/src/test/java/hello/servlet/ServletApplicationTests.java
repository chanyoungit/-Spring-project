package hello.servlet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServletApplicationTests {

	@Test
	void contextLoads() {
	}

}
